﻿namespace PKDSA_OOBC_ClientApp.ViewModels;

public partial class MainViewModel : ViewModelBase
{

}
