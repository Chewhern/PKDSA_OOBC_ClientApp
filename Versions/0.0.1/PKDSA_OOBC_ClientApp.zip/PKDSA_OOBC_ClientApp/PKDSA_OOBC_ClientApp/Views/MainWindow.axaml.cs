﻿using Avalonia.Controls;

namespace PKDSA_OOBC_ClientApp.Views;

public partial class MainWindow : Window
{
    public MainWindow()
    {
        InitializeComponent();
    }
}
